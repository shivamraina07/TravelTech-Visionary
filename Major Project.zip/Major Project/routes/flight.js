const express = require("express");
const router = express.Router();
// const Flight = require("../models/flight.js");

router.get("/", (req, res) => {
    res.render("flights/index.ejs");
})

module.exports = router;